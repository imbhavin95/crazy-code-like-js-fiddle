ace.define("ace/snippets/ftl",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "ftl";

});
